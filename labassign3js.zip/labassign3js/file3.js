// file3.js
const express = require('express');
const app = express();
const PORT = 3000;
const fs = require('fs');
const path = require('path');

app.use(express.json());

// File path for JSON data
const dataPath = path.join(__dirname, 'data', 'cartoons.json');

// GET method to retrieve data
app.get('/cartoons', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) res.status(500).send('Error reading data');
        else res.json(JSON.parse(data));
    });
});

// POST method to add new cartoon character
app.post('/cartoons', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        const cartoons = JSON.parse(data);
        cartoons.push(req.body);
        fs.writeFile(dataPath, JSON.stringify(cartoons), (writeErr) => {
            if (writeErr) res.status(500).send('Error saving data');
            else res.status(201).send('New cartoon character added');
        });
    });
});

// PUT method to update a cartoon character
app.put('/cartoons/:name', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        const cartoons = JSON.parse(data);
        const cartoonIndex = cartoons.findIndex(c => c.name === req.params.name);
        if (cartoonIndex !== -1) {
            cartoons[cartoonIndex] = { ...cartoons[cartoonIndex], ...req.body };
            fs.writeFile(dataPath, JSON.stringify(cartoons), (writeErr) => {
                if (writeErr) res.status(500).send('Error updating data');
                else res.send('Cartoon character updated');
            });
        } else res.status(404).send('Cartoon character not found');
    });
});

// DELETE method to remove a cartoon character
app.delete('/cartoons/:name', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
        const cartoons = JSON.parse(data);
        const updatedCartoons = cartoons.filter(c => c.name !== req.params.name);
        fs.writeFile(dataPath, JSON.stringify(updatedCartoons), (writeErr) => {
            if (writeErr) res.status(500).send('Error deleting data');
            else res.send('Cartoon character deleted');
        });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

