// file2.js
const express = require('express');
const app = express();
const PORT = 3000;
const fs = require('fs');
const path = require('path');

// Route to display JSON content
app.get('/cartoons', (req, res) => {
    const dataPath = path.join(__dirname, 'data', 'cartoons.json');
    fs.readFile(dataPath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error reading JSON file');
        } else {
            res.send(JSON.parse(data));
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
