// file1.js
const express = require('express');
const app = express();
const PORT = 3000;

// Route to display group names
app.get('/', (req, res) => {
    res.send('<h1>Group Members</h1><p>Member 1: [Your Name], Member 2: [Partner’s Name]</p>');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
